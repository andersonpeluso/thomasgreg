import axios from 'axios';

// Define a baseURL da API
const api = axios.create({
  baseURL: 'http://162.55.71.98:45459/api',
});

// Tratamento de erros simplificado
const handleRequestError = (error) => {
  console.error('Erro na requisição:', error.response ? error.response.data : error.message);
  throw error;
};

// Métodos relacionados à entidade "Cliente"
export const getClients = () => 
  api.get('/Cliente').catch(handleRequestError);

export const getClientById = (id) => 
  api.get(`/Cliente/${id}`).catch(handleRequestError);

export const createClient = (data) => 
  api.post('/Cliente', data).catch(handleRequestError);

export const updateClient = (id, data) => 
  api.put(`/Cliente/${id}`, data).catch(handleRequestError);

export const deleteClient = (id) => 
  api.delete(`/Cliente/${id}`).catch(handleRequestError);

// Métodos relacionados à entidade "Logradouro"
export const getLogradouros = () => 
  api.get('/Logradouro').catch(handleRequestError);

export const getLogradouroById = (id) => 
  api.get(`/Logradouro/${id}`).catch(handleRequestError);

export const createLogradouro = (data) => 
  api.post('/Logradouro', data).catch(handleRequestError);

export const updateLogradouro = (id, data) => 
  api.put(`/Logradouro/${id}`, data).catch(handleRequestError);

export const deleteLogradouro = (id) => 
  api.delete(`/Logradouro/${id}`).catch(handleRequestError);
