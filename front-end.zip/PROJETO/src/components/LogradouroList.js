import React, { useEffect, useState } from 'react';
import { getLogradouros, deleteLogradouro } from '../services/apiService';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons';

const LogradouroList = () => {
  const [logradouros, setLogradouros] = useState([]);
  const [loading, setLoading] = useState(true);

  // Função para buscar a lista de logradouros da API
  useEffect(() => {
    const fetchLogradouros = async () => {
      try {
        const response = await getLogradouros();
        setLogradouros(response.data);  // Atualiza o estado com os logradouros
        setLoading(false);  // Desativa o carregamento
      } catch (error) {
        console.error('Erro ao buscar logradouros:', error);
        setLoading(false);  // Desativa o carregamento em caso de erro
      }
    };
    fetchLogradouros();
  }, []);

  // Função para excluir um logradouro
  const handleDelete = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este logradouro?')) {
      try {
        await deleteLogradouro(id);
        setLogradouros(logradouros.filter(log => log.id !== id));  // Remove o logradouro da lista
        alert('Logradouro excluído com sucesso!');
      } catch (error) {
        console.error('Erro ao excluir logradouro:', error);
      }
    }
  };

  const handleEdit = (id) => {
    console.log('Editar logradouro', id);
    // Aqui você pode redirecionar ou abrir um modal de edição
  };

  if (loading) {
    return <div>Carregando logradouros...</div>;  // Exibe mensagem de carregamento
  }

  return (
    <div>
      
      <table className="table">
        <thead>
          <tr>
            <th>Endereço</th>
            <th>Bairro</th>
            <th>Cidade</th>
            <th>Estado</th>
            <th>CEP</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {logradouros.length > 0 ? (
            logradouros.map((log) => (
              <tr key={log.id}>
                <td>{log.endereco}</td>
                <td>{log.bairro}</td>
                <td>{log.cidade}</td>
                <td>{log.estado}</td>
                <td>{log.cep}</td>
                <td>
                  <button 
                    className="btn btn-warning me-2"
                    onClick={() => handleEdit(log.id)}
                  >
                    <FontAwesomeIcon icon={faEdit} /> Editar
                  </button>
                  <button 
                    className="btn btn-danger"
                    onClick={() => handleDelete(log.id)}
                  >
                    <FontAwesomeIcon icon={faTrash} /> Excluir
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6" className="text-center">Nenhum logradouro encontrado.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default LogradouroList;
