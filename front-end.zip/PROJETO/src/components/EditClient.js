import React, { useState, useEffect } from 'react';
import { getClientById, updateClient } from '../services/apiService';

const EditClient = ({ clientId }) => {
  const [client, setClient] = useState(null);

  useEffect(() => {
    getClientById(clientId)
      .then((response) => setClient(response.data))
      .catch((error) => console.error('Erro ao buscar cliente:', error));
  }, [clientId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    updateClient(client)
      .then(() => alert('Cliente atualizado com sucesso!'))
      .catch((error) => console.error('Erro ao atualizar cliente:', error));
  };

  if (!client) return <div className="text-center mt-4">Carregando...</div>;

  return (
    <div className="container mt-4">
      <h2>Editar Cliente</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Nome</label>
          <input
            type="text"
            className="form-control"
            value={client.name}
            onChange={(e) => setClient({ ...client, name: e.target.value })}
          />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            className="form-control"
            value={client.email}
            onChange={(e) => setClient({ ...client, email: e.target.value })}
          />
        </div>
        <div className="form-group">
          <label>CPF</label>
          <input
            type="text"
            className="form-control"
            value={client.cpf}
            onChange={(e) => setClient({ ...client, cpf: e.target.value })}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Atualizar Cliente
        </button>
      </form>
    </div>
  );
};

export default EditClient;
