import React, { useState } from 'react';
import { createClient } from '../services/apiService';

const CreateClient = () => {
  const [client, setClient] = useState({
    nome: '',
    email: '',
    logotipo: '',
    logradouro: [
      {
        endereco: '',
        bairro: '',
        cidade: '',
        estado: '',
        complemento: '',
        cep: ''
      }
    ]
  });

  const handleLogradouroChange = (e) => {
    const { name, value } = e.target;
    setClient({
      ...client,
      logradouro: [{ ...client.logradouro[0], [name]: value }]
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validação simples para garantir que os campos obrigatórios estejam preenchidos
    if (!client.nome || !client.email || !client.logotipo || !client.logradouro[0].cep) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    createClient(client)
      .then(() => alert('Cliente criado com sucesso!'))
      .catch((error) => console.error('Erro ao criar cliente:', error));
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label>Nome</label>
        <input
          type="text"
          className="form-control"
          placeholder="Nome"
          value={client.nome}
          onChange={(e) => setClient({ ...client, nome: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>Email</label>
        <input
          type="email"
          className="form-control"
          placeholder="Email"
          value={client.email}
          onChange={(e) => setClient({ ...client, email: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>Logotipo</label>
        <input
          type="text"
          className="form-control"
          placeholder="URL do Logotipo"
          value={client.logotipo}
          onChange={(e) => setClient({ ...client, logotipo: e.target.value })}
        />
      </div>
      <h4>Endereço</h4>
      <div className="form-group">
        <label>Endereço</label>
        <input
          type="text"
          className="form-control"
          placeholder="Endereço"
          name="endereco"
          value={client.logradouro[0].endereco}
          onChange={handleLogradouroChange}
        />
      </div>
      <div className="form-group">
        <label>Bairro</label>
        <input
          type="text"
          className="form-control"
          placeholder="Bairro"
          name="bairro"
          value={client.logradouro[0].bairro}
          onChange={handleLogradouroChange}
        />
      </div>
      <div className="form-group">
        <label>Cidade</label>
        <input
          type="text"
          className="form-control"
          placeholder="Cidade"
          name="cidade"
          value={client.logradouro[0].cidade}
          onChange={handleLogradouroChange}
        />
      </div>
      <div className="form-group">
        <label>Estado</label>
        <input
          type="text"
          className="form-control"
          placeholder="Estado"
          name="estado"
          value={client.logradouro[0].estado}
          onChange={handleLogradouroChange}
        />
      </div>
      <div className="form-group">
        <label>Complemento</label>
        <input
          type="text"
          className="form-control"
          placeholder="Complemento"
          name="complemento"
          value={client.logradouro[0].complemento}
          onChange={handleLogradouroChange}
        />
      </div>
      <div className="form-group">
        <label>CEP</label>
        <input
          type="text"
          className="form-control"
          placeholder="CEP"
          name="cep"
          value={client.logradouro[0].cep}
          onChange={handleLogradouroChange}
        />
      </div>
      <button type="submit" className="btn btn-primary">Criar Cliente</button>
    </form>
  );
};

export default CreateClient;
