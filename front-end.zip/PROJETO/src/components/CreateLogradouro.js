import React, { useState } from 'react';
import { createLogradouro } from '../services/apiService';

const CreateLogradouro = () => {
  const [logradouro, setLogradouro] = useState({
    endereco: '',
    bairro: '',
    cidade: '',
    estado: '',
    complemento: '',
    cep: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validação básica para garantir que os campos obrigatórios estejam preenchidos
    if (!logradouro.endereco || !logradouro.bairro || !logradouro.cidade || !logradouro.estado || !logradouro.cep) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    createLogradouro(logradouro)
      .then(() => alert('Logradouro criado com sucesso!'))
      .catch((error) => console.error('Erro ao criar logradouro:', error));
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label>Endereço</label>
        <input
          type="text"
          className="form-control"
          placeholder="Endereço"
          value={logradouro.endereco}
          onChange={(e) => setLogradouro({ ...logradouro, endereco: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>Bairro</label>
        <input
          type="text"
          className="form-control"
          placeholder="Bairro"
          value={logradouro.bairro}
          onChange={(e) => setLogradouro({ ...logradouro, bairro: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>Cidade</label>
        <input
          type="text"
          className="form-control"
          placeholder="Cidade"
          value={logradouro.cidade}
          onChange={(e) => setLogradouro({ ...logradouro, cidade: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>Estado</label>
        <input
          type="text"
          className="form-control"
          placeholder="Estado"
          value={logradouro.estado}
          onChange={(e) => setLogradouro({ ...logradouro, estado: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>Complemento</label>
        <input
          type="text"
          className="form-control"
          placeholder="Complemento"
          value={logradouro.complemento}
          onChange={(e) => setLogradouro({ ...logradouro, complemento: e.target.value })}
        />
      </div>
      <div className="form-group">
        <label>CEP</label>
        <input
          type="text"
          className="form-control"
          placeholder="CEP"
          value={logradouro.cep}
          onChange={(e) => setLogradouro({ ...logradouro, cep: e.target.value })}
        />
      </div>
      <button type="submit" className="btn btn-primary">Criar Logradouro</button>
    </form>
  );
};

export default CreateLogradouro;
