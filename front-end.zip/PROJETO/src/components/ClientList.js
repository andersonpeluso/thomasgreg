import React, { useEffect, useState } from 'react';
import { getClients, deleteClient } from '../services/apiService';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons';

const ClientList = () => {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);

  // Função para buscar a lista de clientes da API
  useEffect(() => {
    const fetchClients = async () => {
      try {
        const response = await getClients();
        setClients(response.data);  // Atualiza o estado com os clientes
        setLoading(false);  // Desativa o carregamento
      } catch (error) {
        console.error('Erro ao buscar clientes:', error);
        setLoading(false);  // Desativa o carregamento em caso de erro
      }
    };
    fetchClients();
  }, []);

  // Função para excluir um cliente
  const handleDelete = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este cliente?')) {
      try {
        await deleteClient(id);
        setClients(clients.filter(client => client.id !== id));  // Remove o cliente da lista
        alert('Cliente excluído com sucesso!');
      } catch (error) {
        console.error('Erro ao excluir cliente:', error);
      }
    }
  };

  const handleEdit = (id) => {
    console.log('Editar cliente', id);
    // Aqui você pode redirecionar ou abrir um modal de edição
  };

  if (loading) {
    return <div>Carregando clientes...</div>;  // Exibe mensagem de carregamento
  }

  return (
    <div>
      
      <table className="table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Email</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {clients.length > 0 ? (
            clients.map((client) => (
              <tr key={client.id}>
                <td>{client.nome}</td>
                <td>{client.email}</td>
                <td>
                  <button 
                    className="btn btn-warning me-2"
                    onClick={() => handleEdit(client.id)}
                  >
                    <FontAwesomeIcon icon={faEdit} /> Editar
                  </button>
                  <button 
                    className="btn btn-danger"
                    onClick={() => handleDelete(client.id)}
                  >
                    <FontAwesomeIcon icon={faTrash} /> Excluir
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="3" className="text-center">Nenhum cliente encontrado.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ClientList;
