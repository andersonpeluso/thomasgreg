import React, { useState } from 'react';
import ClientList from './components/ClientList';
import CreateClient from './components/CreateClient';
import LogradouroList from './components/LogradouroList';
import CreateLogradouro from './components/CreateLogradouro';
import './App.css';  // Importação do CSS personalizado para estilização global

function App() {
  // Este estado controla qual seção está ativa no momento (clientes ou logradouros)
  const [activeSection, setActiveSection] = useState(null);

  // Função para manipular cliques no menu e definir a seção ativa
  const handleMenuClick = (section) => {
    setActiveSection(section);
  };

  return (
    <div className="App d-flex">
      <aside className="sidebar bg-primary text-white">
        <h2 className="sidebar-title">Menu</h2>
        <ul className="list-unstyled">
          <li>
            <a
              href="#"  // Prevent default navigation action
              className="text-white"
              onClick={() => handleMenuClick('clients')}  // Ativa a seção de clientes
            >
              Clientes
            </a>
          </li>
          <li>
            <a
              href="#"  // Prevent default navigation action
              className="text-white"
              onClick={() => handleMenuClick('logradouros')}  // Ativa a seção de logradouros
            >
              Logradouros
            </a>
          </li>
        </ul>
      </aside>

      <main className="content p-4">
        <h1 className="text-center">ENGESOFT Consultoria </h1>

        {/* Renderiza a seção de clientes se essa estiver ativa */}
        {activeSection === 'clients' && (
          <section id="clients" className="mt-5">
            <h2>Lista de Clientes</h2>
            <ClientList />  {/* Componente que lista os clientes */}
            <CreateClient />  {/* Componente que adiciona novos clientes */}
          </section>
        )}

        {/* Renderiza a seção de logradouros se essa estiver ativa */}
        {activeSection === 'logradouros' && (
          <section id="logradouros" className="mt-5">
            <h2>Lista de Logradouros</h2>
            <LogradouroList />  {/* Componente que lista os logradouros */}
            <CreateLogradouro />  {/* Componente que adiciona novos logradouros */}
          </section>
        )}
      </main>
    </div>
  );
}

export default App;
